export PATH=/opt/local/scalasca-2.6/bin:/opt/local/ScoreP-8.3/bin:/opt/local/mpich-4.2/bin:/opt/local/Cubelib-4.8/bin:${PATH}
unzip jacobi-example.zip -d jacobi/
